require "nokogiri"
require "open-uri"
url = "votre-url"
doc = Nokogiri::HTML(open(url))




doc.css("div.class a.class").each do |ref|
p ref["attribut"]
end





