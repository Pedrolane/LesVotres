require "nokogiri"
require "open-uri"
url = "http://www.epicurious.com/search/chocolate"
doc = Nokogiri::HTML(open(url))


doc.css("article.gallery-result-item picture.photo-wrap img.photo").each do |ref|
  p ref["data-srcset"]
end


# doc.css("article.gallery-result-item a.view-complete-item").each do |ref|
#   p ref["title"]
# end



