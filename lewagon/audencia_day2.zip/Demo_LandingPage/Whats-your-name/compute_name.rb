def compute_name(first_name, middle_name, last_name)
  # TODO: return full name using string interpolation
  "#{first_name} #{middle_name} #{last_name}"
end
