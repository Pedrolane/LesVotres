# Setup instructions

## Homebrew

On Mac, you need to install [Homebrew](http://brew.sh/) which is a Package Manager.
It will be used as soon as we need to install some software.
To do so, open your Terminal and run:

```bash
ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

This will ask for your confirmation (hit `Enter`) and your laptop session password.

If you already have Homebrew, it will tell you so, that's fine, go on.

Then install some useful software:

```bash
brew update
```

If you get a `/usr/local must be writable` error, just run this:

```bash
sudo chown -R $USER:admin /usr/local
brew update
```

## Installing Ruby (with [rbenv](https://github.com/sstephenson/rbenv))

First we need to clean up any previous Ruby installation you might have:

```bash
rvm implode && sudo rm -rf ~/.rvm
# If you got "zsh: command not found: rvm", carry on. It means `rvm` is not
# on your computer, that's what we want!

sudo rm -rf $HOME/.rbenv /usr/local/rbenv /opt/rbenv /usr/local/opt/rbenv
```

Now let's get `rbenv` and `ruby-build` packages from Homebrew, they'll be useful.

```bash
brew uninstall --force rbenv ruby-build
unset RBENV_ROOT
brew install rbenv ruby-build
```

Now, you are ready to install the latest ruby version, and set it as the default version.

Run this command, it will **take a while (5-10 minutes)**

```bash
rbenv install 2.3.1
```

Once the ruby installation is done, run this command tell the system
to use the 2.3.1 version by default.

```bash
rbenv global 2.3.1
```

Then **restart** your Terminal (close it and reopen it).

```bash
ruby -v
```

You should see something starting with `ruby 2.3.1p`. If not,

```bash
cd
touch .bash_profile
echo "export PATH="$HOME/.rbenv/shims:$PATH"" > .bash_profile
ruby -v
```
Now, you should see something starting with `ruby 2.3.1p`

```bash
gem install bundler
```

Now download the project of the day

```bash
bit.ly/LWday3
```

Drag and drop the folder 'benchmarker' in terminal add cd before the app, press enter

```bash
bundle install
```






