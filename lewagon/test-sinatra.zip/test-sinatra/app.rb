
require "sinatra"
require "sinatra/reloader"
require "open-uri"
require "nokogiri"
require "pry-byebug" if development?
require "better_errors" if development?
configure :development do
  use BetterErrors::Middleware
  BetterErrors.application_root = File.expand_path('..', __FILE__)
end


get '/' do
  my_search = params[:search]
  if my_search == nil
  else
  html_file = open("http://www.epicurious.com/search/#{my_search}")
  html_doc = Nokogiri::HTML(html_file)

  @recipes_epicurious = []
  html_doc.css("article.gallery-result-item h4.hed a").each do |recipe|
    recipe_info =[]
    recipe_info << recipe.text
    recipe_info << recipe["href"]
    @recipes_epicurious << recipe_info
    end
  end
  erb :index
end


get '/about' do
  erb :about
end

get '/team/:username' do
  puts params[:username]
  "The username is #{params[:username]}"
end

